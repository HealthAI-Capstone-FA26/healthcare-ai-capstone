import { Injectable } from '@nestjs/common';

@Injectable()
export class MedicationService {
  // TODO: xử lý nghiệp vụ
}
