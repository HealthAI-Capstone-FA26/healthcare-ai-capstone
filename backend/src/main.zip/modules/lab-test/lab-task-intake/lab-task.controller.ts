import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
import {
    ApiConflictResponse,
    ApiForbiddenResponse,
    ApiBadRequestResponse,
    ApiNotFoundResponse,
    ApiOkResponse,
    ApiOperation,
    ApiParam,
    ApiTags,
} from '@nestjs/swagger';
import { LabTaskService } from './lab-task.service';
import { ListLabTasksQueryDto } from './dtos/list-lab-tasks-query.dto';
import { AssignLabTaskDto } from './dtos/assign-lab-task.dto';
import { ReceiveLabTaskDto } from './dtos/receive-lab-task.dto';
import { ReportLabTaskExceptionDto } from './dtos/report-lab-task-exception.dto';

/**
 * Tiếp nhận & vòng đời nhiệm vụ xét nghiệm (LabTask), do Kỹ thuật viên phòng Lab thao tác.
 * TODO: gắn Guard role LAB_STAFF + kiểm tra req.user thuộc đúng labRoomId khi có auth module.
 *
 * LƯU Ý: controller này KHÔNG có endpoint huỷ chủ động. Phòng Lab không có thẩm quyền huỷ chỉ
 * định bác sĩ — nó chỉ có thể báo cáo ngoại lệ (xem `report-exception` bên dưới). Việc huỷ
 * ('cancelled') chỉ xảy ra như hệ quả cascade từ module Order, xem LabTaskOrderCancellationListener.
 */
@ApiTags('Lab Tasks')
@Controller('lab-tasks')
export class LabTaskController {
    constructor(private readonly labTaskService: LabTaskService) { }

    /**
     * GET /lab-tasks?labRoomId=...&status=...&assignedLabStaffId=...
     * Worklist của 1 phòng Lab — bắt buộc lọc theo labRoomId vì kỹ thuật viên chỉ được
     * xem/thao tác trong phạm vi phòng chuyên môn mình phụ trách.
     */
    @Get()
    @ApiOperation({
        summary: 'Worklist nhiệm vụ xét nghiệm của 1 phòng Lab',
        description: 'Trả về danh sách LabTask theo phòng Lab, có thể lọc thêm theo trạng thái và kỹ thuật viên phụ trách.',
    })
    @ApiOkResponse({ description: 'Danh sách nhiệm vụ xét nghiệm.' })
    async list(@Query() query: ListLabTasksQueryDto) {
        return this.labTaskService.listWorklist(query);
    }

    @Get(':id')
    @ApiOperation({ summary: 'Chi tiết 1 nhiệm vụ xét nghiệm' })
    @ApiParam({ name: 'id', description: 'ID nhiệm vụ xét nghiệm (labTaskId)', format: 'uuid' })
    @ApiOkResponse({ description: 'Chi tiết nhiệm vụ, kèm kết quả (nếu đã có).' })
    @ApiNotFoundResponse({ description: 'Không tìm thấy nhiệm vụ xét nghiệm.' })
    async detail(@Param('id') id: string) {
        return this.labTaskService.getById(id);
    }

    /**
     * POST /lab-tasks/:id/verify-payment
     * Gọi bởi module Thanh toán (webhook/event) ngay khi hoá đơn được thanh toán thành công.
     * Đây là điều kiện tiên quyết để nhiệm vụ có thể được tiếp nhận thực hiện.
     */
    @Post(':id/verify-payment')
    @ApiOperation({
        summary: 'Xác nhận thanh toán cho 1 nhiệm vụ xét nghiệm',
        description:
            "Đánh dấu paymentVerified = true và chuyển trạng thái từ 'payment_pending' sang 'ready'. " +
            'Idempotent — an toàn khi gọi lại nhiều lần (VD: webhook thanh toán retry).',
    })
    @ApiParam({ name: 'id', description: 'ID nhiệm vụ xét nghiệm (labTaskId)', format: 'uuid' })
    @ApiOkResponse({ description: 'Nhiệm vụ sau khi xác nhận thanh toán.' })
    @ApiNotFoundResponse({ description: 'Không tìm thấy nhiệm vụ xét nghiệm.' })
    async verifyPayment(@Param('id') id: string) {
        return this.labTaskService.verifyPayment(id);
    }

    @Patch(':id/assign')
    @ApiOperation({
        summary: 'Gán trước hoặc chuyển (reassign) kỹ thuật viên phụ trách nhiệm vụ',
        description:
            'Dùng để pre-assign một KTV cụ thể trước khi task được tự nhận, hoặc để chuyển task đang ' +
            "'in_progress' sang KTV khác. KTV được gán phải thuộc phòng Lab của nhiệm vụ " +
            '(LabStaffRoomAssignment). Không áp dụng cho task đã completed/cancelled.',
    })
    @ApiParam({ name: 'id', description: 'ID nhiệm vụ xét nghiệm (labTaskId)', format: 'uuid' })
    @ApiOkResponse({ description: 'Nhiệm vụ sau khi gán kỹ thuật viên.' })
    @ApiBadRequestResponse({
        description: "Kỹ thuật viên không thuộc phòng Lab của nhiệm vụ, hoặc nhiệm vụ đã completed/cancelled.",
    })
    async assign(@Param('id') id: string, @Body() dto: AssignLabTaskDto) {
        return this.labTaskService.assign(id, dto);
    }

    /**
     * POST /lab-tasks/:id/receive
     * Kỹ thuật viên tiếp nhận chỉ định để bắt đầu thực hiện xét nghiệm.
     * Bị từ chối (403) nếu bệnh nhân chưa hoàn tất thanh toán — đây là điểm thực thi
     * chính của ràng buộc "chỉ tiến hành khi đã thanh toán".
     */
    @Post(':id/receive')
    @ApiOperation({
        summary: 'Tiếp nhận nhiệm vụ xét nghiệm để bắt đầu thực hiện',
        description:
            "Chuyển trạng thái 'ready' -> 'in_progress'. Bị từ chối nếu bệnh nhân chưa thanh toán " +
            "(paymentVerified = false / status = 'payment_pending'). Việc chiếm task được thực hiện " +
            'atomic ở tầng DB (compare-and-swap) — nếu 2 KTV cùng bấm nhận 1 task trống cùng lúc, ' +
            'chỉ 1 request thành công, request còn lại nhận 409 Conflict.',
    })
    @ApiParam({ name: 'id', description: 'ID nhiệm vụ xét nghiệm (labTaskId)', format: 'uuid' })
    @ApiOkResponse({ description: 'Nhiệm vụ sau khi tiếp nhận (status = in_progress).' })
    @ApiForbiddenResponse({
        description:
            'Bệnh nhân chưa hoàn tất thanh toán, hoặc nhiệm vụ đã được phân công cho kỹ thuật viên khác.',
    })
    @ApiBadRequestResponse({ description: "Nhiệm vụ không ở trạng thái 'ready'." })
    @ApiConflictResponse({
        description: 'Nhiệm vụ vừa được kỹ thuật viên khác tiếp nhận trước đó (race condition).',
    })
    async receive(@Param('id') id: string, @Body() dto: ReceiveLabTaskDto) {
        return this.labTaskService.receive(id, dto);
    }

    /**
     * POST /lab-tasks/:id/report-exception
     * Phòng Lab báo cáo KHÔNG THỂ tiếp tục thực hiện (mẫu bị từ chối, bệnh nhân không có mặt...).
     * Đây KHÔNG phải huỷ — task chỉ chuyển sang 'on_hold' và phát event để bác sĩ/module Order
     * quyết định bước tiếp theo (huỷ hẳn chỉ định, hoặc yêu cầu lấy lại mẫu).
     */
    @Post(':id/report-exception')
    @ApiOperation({
        summary: 'Báo cáo ngoại lệ khiến phòng Lab không thể tiếp tục thực hiện',
        description:
            "Chuyển trạng thái sang 'on_hold' (trung gian, KHÔNG kết thúc) và phát event cho bác sĩ/" +
            'module Order biết để quyết định bước tiếp theo. Phòng Lab không có quyền tự huỷ chỉ định.',
    })
    @ApiParam({ name: 'id', description: 'ID nhiệm vụ xét nghiệm (labTaskId)', format: 'uuid' })
    @ApiOkResponse({ description: "Nhiệm vụ sau khi báo cáo (status = on_hold)." })
    @ApiBadRequestResponse({
        description: "Nhiệm vụ đã completed/cancelled/on_hold, không thể báo cáo ngoại lệ thêm.",
    })
    async reportException(@Param('id') id: string, @Body() dto: ReportLabTaskExceptionDto) {
        return this.labTaskService.reportException(id, dto);
    }
}